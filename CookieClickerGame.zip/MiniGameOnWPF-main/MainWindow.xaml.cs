﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CookieClicker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int counter = 0;
        int number = 0;
        int chance = 0;
        bool isDouble = false;
        int prize = 100;
        int randomNumberLotery = 10;
        Random random = new Random();
        int randonNumber = 100;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void DoubleButton(object sender, RoutedEventArgs e)
        {
            if (number < 5)
            {
                result.Text = "You don't have enough money";
                money.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;


            }
            else
            {
                MessageBox.Show("You did a good choice");
                number = number - 5;
                result.Text = "You have: " + number;
                isDouble = true;
                doubleButton.IsEnabled = false;
            }
            
        }

        private void Main_Click(object sender, RoutedEventArgs e)
        {
            if (isDouble == false)
            {
                ++number;
                result.Text = "You have: " + number.ToString();
            }
            if (isDouble == true)
            {
               
                number = number + 100;
                result.Text = "You have: " + number.ToString();
            }
        }

        private void confirm_Click(object sender, RoutedEventArgs e)
        {
            money.Visibility = Visibility.Collapsed;
            lose.Visibility = Visibility.Collapsed;
            win.Visibility = Visibility.Collapsed;
            smile.Visibility = Visibility.Collapsed;
            confirm.Visibility = Visibility.Collapsed;

            result.Text = "You have: " + number.ToString();
        }

        private void Lucky_Click(object sender, RoutedEventArgs e)
        {
            if (number <5)
            {
                result.Text = "You don't have enough money";
                money.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                return;
            }


            chance = random.Next(101);
            number = number - 10;
          if (chance >= randonNumber)
            {
                win.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                number = number + prize;
                result.Text = "You have: " + number.ToString();
            }
            else
            {
                lose.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                result.Text = "You have: " + number.ToString();
            }
        }

        private void Effort_Lucky(object sender, RoutedEventArgs e)
        {
            if (number < 5)
            {
                result.Text = "You don't have enough money";
                money.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                return;
            }
            if (counter == 2)
            {
                effortLucky.IsEnabled = false;
            }

            number = number - 5;
            ++counter;     
            randonNumber = randonNumber - counter;
            result.Text = "You have: " + number.ToString();
            MessageBox.Show($"Now your chance to get 100 cookies is {counter+1} %");

        }

        private void Add_Cookie(object sender, RoutedEventArgs e)
        {
            if (number < 5)
            {
                result.Text = "You don't have enough money";
                money.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                return;
            }
            number = number - 5;
            result.Text = "You have: " + number.ToString();
            ++prize;
            MessageBox.Show($"if you will win the Lucky case you will get {prize} ");
        }

        private void MultiplyButton(object sender, RoutedEventArgs e)
        {
            if (number < 100)
            {
                result.Text = "You don't have enough money";
                money.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                return;
            }
            number = number - 100;
            number = number * 3;
            if (number == 0)
            {
                smile.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
            }
          
            result.Text = "You have: " + number.ToString();

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (number < 100)
            {
                result.Text = "You don't have enough money";
                money.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                return;
            }
            number = number - 100;

            int rand = random.Next(100);
            if (rand <= randomNumberLotery)
            {
                win.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                number = number + 1000;
                result.Text = "You have: " + number.ToString();
            }
            else
            {
                lose.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                result.Text = "You have: " + number.ToString();
            }

        }

        private void Buy(object sender, RoutedEventArgs e)
        {
            if (number < 5)
            {
                result.Text = "You don't have enough money";
                money.Visibility = Visibility.Visible;
                confirm.Visibility = Visibility.Visible;
                return;
            }
            number = number - 5;


            if (randomNumberLotery == 20)
            {
                buy.IsEnabled = false;
            }
            
            ++randomNumberLotery;
            MessageBox.Show($"Now you have {randomNumberLotery} chance");
            result.Text = "You have: " + number.ToString();
        }
    }
}
