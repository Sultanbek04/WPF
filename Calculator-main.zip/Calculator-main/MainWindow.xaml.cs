﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ComplexCalculatorWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int counter1 = 1;
        int counter2 = 2;
        int counter3 = 3;
        
        double firstResult = 0;
        double secondResult = 0;
      
        bool work = true;
        string str = null;
        string[] engineerOperations= { "Log", "Sin", "Cos", "Modul" };

        Button[] buttons = new Button[15];
        
        

        public MainWindow()
        {
            InitializeComponent();
           
            plus.Click += Operation_Button;
            minus.Click += Operation_Button;
            multiply.Click += Operation_Button;
            divide.Click += Operation_Button;

            for (int i = 0; i < 10; ++i)
            {

                if (i <= 2)
                {
                    var button = new Button();
                    button = ButtonDecoration(button);

                    button.Content = counter1.ToString();
                    counter1 = counter1 + 3;
                    buttons[i] = button;
                    standartCalculator1.Children.Add(button);
                }
                if (i <= 5 && i >= 3)
                {

                    var button = new Button();
                    button = ButtonDecoration(button);
                    button.Margin = new Thickness(55, 0, 0, 0);
                    button.Content = counter2.ToString();
                    counter2 = counter2 + 3;
                    buttons[i] = button;
                    standartCalculator2.Children.Add(button);
                }
                if (i <= 8 && i >= 6)
                {

                    var button = new Button();
                    button = ButtonDecoration(button);
                    button.Margin = new Thickness(110, 0, 0, 0);
                    button.Content = counter3.ToString();
                    counter3 = counter3 + 3;
                    buttons[i] = button;
                    standartCalculator3.Children.Add(button);
                }

            }
          
            var buttonZero = new Button();
            buttonZero = ButtonDecoration(buttonZero);
            buttonZero.Content = "0";
            buttons[9] = buttonZero;
            standartCalculator1.Children.Add(buttonZero);

            var buttonMinus = new Button();
            buttonMinus = ButtonDecoration(buttonMinus);
            buttonMinus.Content = "-";
            buttons[14] = buttonMinus;
            standartCalculator1.Children.Add(buttonMinus);


            var buttonX = new Button();
            buttonX = ButtonDecoration(buttonX);
            buttonX.Content = "X";
            buttonX.Margin = new Thickness(55, 0, 0, 0);
            buttonX.Click += Clear_Digit_Click;
            standartCalculator2.Children.Add(buttonX);


            var buttonComma = new Button();
            buttonComma = ButtonDecoration(buttonComma);
            buttonComma.Content = ".";
            buttonComma.Click += Comma_Click;
            buttonComma.Margin = new Thickness(110, 0, 0, 0);

            standartCalculator3.Children.Add(buttonComma);

            var buttonSin = new Button();
            buttonSin = ButtonDecoration(buttonSin);     
            buttonSin.Content = "Sin";      
            buttonSin.Margin = new Thickness(165, 0, 0, 0);
            buttons[10] = buttonSin;
            engineerCalculator.Children.Add(buttonSin);


            var buttonCos = new Button();
            buttonCos = ButtonDecoration(buttonCos);
            buttonCos.Content = "Cos";
            buttonCos.Margin = new Thickness(165, 0, 0, 0);
            buttons[11] = buttonCos;          
            engineerCalculator.Children.Add(buttonCos);

            var buttonLog = new Button();
            buttonLog = ButtonDecoration(buttonLog);
            buttonLog.Content = "Log ";
            buttonLog.Margin = new Thickness(165, 0, 0, 0);
            buttons[12] = buttonLog;
            engineerCalculator.Children.Add(buttonLog);

            var buttonModul = new Button();
            buttonModul = ButtonDecoration(buttonModul);
            buttonModul.Content = "Modul";
            buttonModul.Margin = new Thickness(165, 0, 0, 0);
            buttons[13] = buttonModul;
            engineerCalculator.Children.Add(buttonModul);

            

        }

        private void Turn_On()
        {
            standartCalculator1.Visibility = Visibility.Visible;
            standartCalculator2.Visibility = Visibility.Visible;
            standartCalculator3.Visibility = Visibility.Visible;
            standartCalculator4.Visibility = Visibility.Visible;
            standartCalculator5.Visibility = Visibility.Visible;
            operations.Visibility = Visibility.Visible;
            creator.Visibility = Visibility.Collapsed;
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }
     
            public Button ButtonDecoration(Button button)
            {
                button.Click += Number;
                button.Width = 55;
                button.Height = 60;

                button.Foreground = new SolidColorBrush(Colors.Red);
                button.Background = new SolidColorBrush(Colors.AliceBlue);
                button.BorderBrush = new SolidColorBrush(Colors.Violet);
                button.HorizontalAlignment = HorizontalAlignment.Left;
                return button;
            }

            

            private void SC_Click(object sender, RoutedEventArgs e)
            {


            Turn_On();
            engineerCalculator.Visibility = Visibility.Collapsed;

            }

        private void EC_Click(object sender, RoutedEventArgs e)
        {

            Turn_On();
            engineerCalculator.Visibility = Visibility.Visible;
        }
            private void Number(object sender, RoutedEventArgs e)
            {
            if(ft.Text.StartsWith("-") && sender == buttons[14] && work==true)
            {
                return;
            }


            if(sender==buttons[14] && ft.Text.Contains("-") && work==true)
            {           
                return;            
            }

            if (st.Text.StartsWith("-") && sender == buttons[14] && work == false)
            {
                return;
            }

            if (sender == buttons[14] && st.Text.Contains("-") && work == false)
            {
                return;
            }

            if (ft.Text.Length >= 1 && sender == buttons[14] && work == true)
            {
                return;
            }


            if (st.Text.Length>=1 && sender==buttons[14] && work == false)
            {
                return;
            }


            for (int i = 0; i < buttons.Length; ++i)
                {
             
                
                   if (sender == buttons[i] && work == true)
                    {
                    
                        ft.Text = ft.Text + buttons[i].Content.ToString();
                    }
                    if (sender == buttons[i] && work == false)
                    {
                        st.Text = st.Text + buttons[i].Content.ToString();
                    }
                }
            }

            private void FirstNumber_Click(object sender, RoutedEventArgs e)
            {
                work = true;
                firstNumber.Foreground = new SolidColorBrush(Colors.OrangeRed);
                firstNumber.Background = new SolidColorBrush(Colors.AliceBlue);
                secondNumber.Background = new SolidColorBrush(Colors.AliceBlue);
                secondNumber.Background = new SolidColorBrush(Colors.Gray);

            }
            private void SecondNumber_Click(object sender, RoutedEventArgs e)
            {
                work = false;
                secondNumber.Foreground = new SolidColorBrush(Colors.OrangeRed);
                secondNumber.Background = new SolidColorBrush(Colors.AliceBlue);
                firstNumber.Background = new SolidColorBrush(Colors.Gray);

            }


        private void Operation_Button(object sender, RoutedEventArgs e)
        {
           
                if (sender == plus)
                {
                    operation.Text = "+";

                }
                if (sender == minus)
                {
                    operation.Text = "-";

                }
                if (sender == multiply)
                {
                    operation.Text = "*";


                }
                if (sender == divide)
                {
                    operation.Text = "/";

                }

            }
        
            private void Clear_Click(object sender, RoutedEventArgs e)
            {
                ft.Text = "";
                st.Text = "";
                operation.Text = "";
                result.Text = "Result" + "";
            information.Text = "";
          
            buttons[14].IsEnabled = true;
            }
        private void Count_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                for (int i = 0; i < engineerOperations.Length; ++i)
                {
                    if (ft.Text.Contains(engineerOperations[i]))
                    {
                        if (engineerOperations[i] == "Sin")
                        {
                            str = ft.Text.Replace("Sin", "");
                            firstResult = Math.Sin(Convert.ToDouble(str));

                        }
                        if (engineerOperations[i] == "Cos")
                        {
                            str = ft.Text.Replace("Cos", "");
                            firstResult = Math.Cos(Convert.ToDouble(str));

                        }
                        if (engineerOperations[i] == "Log")
                        {
                            str = ft.Text.Replace("Log", "");
                            firstResult = Math.Log10(Convert.ToDouble(str));

                        }
                        if (engineerOperations[i] == "Modul")
                        {
                            str = ft.Text.Replace("Modul", "");
                            if (str.Contains("-"))
                            {
                                str = str.Replace("-", "");
                            }
                            firstResult = Convert.ToDouble(str);
                        }
                    }
                    if (i + 1 == engineerOperations.Length && firstResult == 0)
                    {
                        firstResult = Convert.ToDouble(ft.Text);
                    }
                }
                for (int i = 0; i < engineerOperations.Length; ++i)
                {

                    if (st.Text.Contains(engineerOperations[i]))
                    {
                        if (engineerOperations[i] == "Sin")
                        {
                            str = st.Text.Replace("Sin", "");
                            secondResult = Math.Sin(Convert.ToDouble(str));

                        }
                        if (engineerOperations[i] == "Cos")
                        {
                            str = st.Text.Replace("Cos", "");
                            secondResult = Math.Cos(Convert.ToDouble(str));

                        }
                        if (engineerOperations[i] == "Log")
                        {
                            str = st.Text.Replace("Log", "");
                            secondResult = Math.Log10(Convert.ToDouble(str));

                        }
                        if (engineerOperations[i] == "Modul")
                        {
                            str = st.Text.Replace("Modul", "");
                            if (str.Contains("-"))
                            {
                                str = str.Replace("-", "");
                            }
                            secondResult = Convert.ToDouble(str);
                        }
                    }
                    if (i + 1 == engineerOperations.Length && secondResult == 0)
                    {
                        secondResult = Convert.ToDouble(st.Text);
                    }
                }
            
                if (operation.Text == "-")
                {

                    result.Text = "Result:" + (firstResult - secondResult).ToString();
                }

                if (operation.Text == "*")
                {
                    result.Text = "Result:" + (firstResult * secondResult).ToString();
                }

                if (operation.Text == "/")
                {
                    result.Text = "Result:" + (firstResult / secondResult).ToString();
                }


                if (operation.Text == "+")
                {
                    result.Text = "Result:" + (firstResult + secondResult).ToString();
                }
            }


            catch (Exception ex)
            {
                information.Text = ex.Message;
            }
            }
        private void Clear_Digit_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                if (work == true)
                {


                    ft.Text = ft.Text.Remove(ft.Text.Length - 1);
                }
                else
                {

                    st.Text = st.Text.Remove(st.Text.Length - 1);
                }
            }
            catch(Exception ex)
            {
                information.Text = ex.Message;
            }
            }
        
          
            
            private void Comma_Click(object sender, RoutedEventArgs e)
            {

                if (work == true && !ft.Text.Contains(","))
                {
                    ft.Text = ft.Text + ",";

                }
                if (work == false && !st.Text.Contains(","))
                {
                    st.Text = st.Text + ",";
                }
            }
        private void Information_Click(object sender, RoutedEventArgs e)
        {
            standartCalculator1.Visibility = Visibility.Collapsed;
            standartCalculator2.Visibility = Visibility.Collapsed;
            standartCalculator3.Visibility = Visibility.Collapsed;
            standartCalculator4.Visibility = Visibility.Collapsed;
            standartCalculator5.Visibility = Visibility.Collapsed;
            engineerCalculator.Visibility = Visibility.Collapsed;
            operations.Visibility = Visibility.Collapsed;
            creator.Visibility = Visibility.Visible;
        }
        }
    }

