﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GuessTheColor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int counter = 0;
        Button button = new Button();
        Random random = new Random();
        Button[] buttons = new Button[6];
        SolidColorBrush[] brushes = new SolidColorBrush[6];
        string[] randomColors = new string[6] { "Black", "Red", "Green", "Maroon", "Brown", "Blue" };
       
        public MainWindow()
        {

            InitializeComponent();
     
            brushes[0] = new SolidColorBrush(Colors.Black);
            brushes[1] = new SolidColorBrush(Colors.Red);
            brushes[2] = new SolidColorBrush(Colors.Green);
            brushes[3] = new SolidColorBrush(Colors.Maroon);
            brushes[4] = new SolidColorBrush(Colors.Brown);
            brushes[5] = new SolidColorBrush(Colors.Blue);


            button.Width = 20000;
            button.Height = 350;
            button.Background = brushes[random.Next(0, 6)];
            button.VerticalAlignment = VerticalAlignment.Top;
            contents.Children.Add(button);

            for (int i = 0; i < randomColors.Length; ++i)
            {
                var buttonChoosen = new Button();
                buttonChoosen.Click += Name_Click;
                buttonChoosen.Content = randomColors[i];
                buttonChoosen.Name = brushes[i].Color.ToString().Replace("#", "b");
                buttonChoosen.Background = new SolidColorBrush(Colors.AliceBlue);
                buttonChoosen.Width = 100;
                buttons[i] = buttonChoosen;
                choicies.Children.Add(buttonChoosen);

            }



        }
        private void Name_Click(object sender, RoutedEventArgs e)
        {


            string str = button.Background.ToString();
            str = str.Replace("#", "b");

            if (sender == buttons.Where(s => s.Name == str).FirstOrDefault())
            {
                button.Background = brushes[random.Next(0, 6)];
                ++counter;
                scores.Width = 300;
                scores.FontSize = 50;
                scores.FontWeight = FontWeights.Bold;
                scores.Foreground = new SolidColorBrush(Colors.Coral);
                scores.FontStyle = FontStyles.Italic;
                scores.Text = "Score:" + counter.ToString();

            }
            else
            {
                check.VerticalAlignment = VerticalAlignment.Center;
                check.Width = 500;
                check.Height = 500;
                check.FontSize = 50;
                check.Foreground = new SolidColorBrush(Colors.Red);
                choicies.Visibility = Visibility.Collapsed;
                button.Visibility = Visibility.Collapsed;
                
                check.Text = "YOU LOST!";
                check.Visibility = Visibility.Visible;
   
                

            }

        }
       
    }
}
