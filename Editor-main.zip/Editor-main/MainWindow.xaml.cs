﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EditorWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Button[] buttons = new Button[40];
        OpenFileDialog fileDialog = new OpenFileDialog();
      
        public MainWindow()
        {
            InitializeComponent();
        

              for(int i = 0; i < buttons.Length; ++i)
              {
                var button = new Button();
                button.Height = 20;
                button.Width = 20;
                button.Content = (i+1).ToString();
                button.HorizontalAlignment = HorizontalAlignment.Left;
                button.Click += Size_Click;
               buttons[i] = button;
              }   
              for(int i=0; i < buttons.Length; ++i)
            {
                sizes.Children.Add(buttons[i]);
            }
        }

        private void Load_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "txt file|*.txt";
            ofd.ShowDialog();

            if (ofd.ShowDialog() == true)
            {

                using (StreamReader sr = new StreamReader(ofd.FileName))
                {
                    text.Text = sr.ReadToEnd();
                    fileDialog = ofd;
                }
            }
        }

        private void SaveInformationInFileWhichWasLastOpened(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog ofd = new SaveFileDialog();

                using (StreamWriter sr = new StreamWriter(fileDialog.FileName))
                {
                    
                    sr.Write(text.Text);
                   information.Text = "Operation is completed successfully";
                } 
            }
            catch(Exception ex)
            {
                information.Text = ex.Message;
            }
                   
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {

            SaveFileDialog ofd = new SaveFileDialog();
            ofd.Filter = "txt file|*.txt";
            ofd.ShowDialog();


            if (ofd.ShowDialog() == true)
            {
                using (StreamWriter sr = new StreamWriter(ofd.FileName))
                {
                    sr.Write(text.Text);
                }
            }
        }
        private void Size_Click(object sender, RoutedEventArgs e)
        {
           
            for(int i = 0; i < buttons.Length; ++i)
            {
                if (sender == buttons[i])
                {
                    text.FontSize = i+1;                
                }
            }

        }

        private void bold_Click(object sender, RoutedEventArgs e)
        {
            text.FontWeight = FontWeights.Bold;
        }

        private void thin_Click(object sender, RoutedEventArgs e)
        {
            text.FontWeight = FontWeights.Thin;
        }

        private void standart_Click(object sender, RoutedEventArgs e)
        {
            text.FontWeight = FontWeights.Regular;
        }       
    }
}
   

