﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfControlLibrary1
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void Load_Click (object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "jpg file|*.jpg";
            ofd.ShowDialog();
            
            if (ofd.ShowDialog() == true)
            {
                var uri = new Uri(ofd.FileName);
                var bitmap = new BitmapImage(uri);
                image.Source = bitmap;

               
                image.Width = 300;
                image.Height = 400;
            }
        }
        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var rotate = new RotateTransform(Convert.ToDouble(tbRotation.Text));
                var scale= new ScaleTransform(Convert.ToDouble(tbScaleX.Text), Convert.ToDouble(tbScaleY.Text));
                var compress = new SkewTransform(Convert.ToDouble(tbCompressX.Text), Convert.ToDouble(tbCompressY.Text));
                TransformGroup transformGroup = new TransformGroup();
                transformGroup.Children.Add(scale);
                transformGroup.Children.Add(rotate);
                transformGroup.Children.Add(compress);
              
                image.RenderTransform = transformGroup;
               
                
            }
            catch(Exception ex)
            {
                information.Text = ex.Message;
            }
        }
    }
}
   
    

